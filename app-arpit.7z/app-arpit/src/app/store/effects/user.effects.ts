import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import * as UserActions from '../Actions/user.actions';
import { catchError, map, mergeMap, of } from 'rxjs';
import { UserService } from 'src/app/services/user.service';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class UserEffects {
  constructor(private actions$: Actions, private userService: UserService,  private toastr: ToastrService) {}

  loadUsers$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserActions.loadUsers),
      mergeMap(() =>
        this.userService.getUsers().pipe(
          map((users) => UserActions.loadUsersSuccess({ users })),
          catchError((error) => of(UserActions.loadUsersFailure({ error })))
        )
      )
    )
  );

  addUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserActions.addUser),
      mergeMap((action) =>
        this.userService.addUser(action.user).pipe(
          map((user) => {
            this.toastr.success('User added successfully!');
            return UserActions.addUserSuccess({ user });
          }),
          catchError((error) => {
            let errorMessage = 'An unexpected error occurred.';
            if (error.error && error.error.message) {
              errorMessage = error.error.message;
            } else if (error.message) {
              errorMessage = error.message;
            }
            this.toastr.error(errorMessage);
            return of(UserActions.addUserFailure({ error: { message: errorMessage } }));
          })
        )
      )
    )
  );
}
