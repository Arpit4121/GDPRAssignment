import { ActionReducerMap } from '@ngrx/store';
import { userReducer } from './user.reducer';
import { UserState } from '../state/user.state';

export interface AppState {
  user: UserState;
}

export const reducers: ActionReducerMap<AppState> = {
  user: userReducer,
};
