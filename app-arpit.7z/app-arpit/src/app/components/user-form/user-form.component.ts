import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from 'src/app/models/user.model';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.scss']
})
export class UserFormComponent implements OnInit {
  @Output() addUser = new EventEmitter<User>();
  userForm: FormGroup = this.fb.group({});
  
  constructor(private fb: FormBuilder) {
    this.initializeForm()
  }

  ngOnInit(){
    
  }
  initializeForm(){
    this.userForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      address: ['', Validators.required],
      hasConsented: [false]
    });
  }

  onSubmit() {
    if (this.userForm?.valid) {
      const newUser: User = {
        ...this.userForm.value,
      };
      this.addUser.emit(newUser);
      this.userForm.reset();
      this.userForm.get('hasConsented')?.setValue(false)
    }
  }
}
