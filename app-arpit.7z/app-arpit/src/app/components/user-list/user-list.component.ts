import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { User } from '../../models/user.model';
import * as fromUserSelectors from '../../store/selectors/user.selectors';
import * as UserActions from '../../store/Actions/user.actions';
import { UserState } from '../../store/state/user.state';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss'],
})
export class UserListComponent implements OnInit {
  users$: Observable<User[]>;
  loading$: Observable<boolean>;
  constructor(private store: Store<UserState>) {
    this.users$ = this.store.select(fromUserSelectors.selectAllUsers);
    this.loading$ = this.store.select(fromUserSelectors.selectUserLoading);
  }

  ngOnInit(): void {
    this.store.dispatch(UserActions.loadUsers());
  }

  onAddUser(user: User) {
    this.store.dispatch(UserActions.addUser({ user }));
  }
}
