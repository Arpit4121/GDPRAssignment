﻿public class BinaryStringAnalysis
{
    public static bool IsGoodBinaryString(string binaryString)
    {
        int onesCount = 0;
        int zerosCount = 0;

        foreach (char bit in binaryString)
        {
            if (bit == '1')
                onesCount++;
            else if (bit == '0')
                zerosCount++;
            else
                return false;

            if (onesCount < zerosCount)
                return false;
        }
        return onesCount == zerosCount;
    }
    public static void Main(string[] args)
    {
        // TestCases or Examples
        // 1100 - Equal number of 1's and 0's and valid prefix condition - Good
        // 1001 - Fails prefix condition (more 0's at some prefix) - Bad
        // 1010 - Valid binary string with equal 1's and 0's - Good
        // 0101 - First prefix has more 0's than 1's - Bad
        string[] testCases = { "1100", "1001", "1010", "0101" }; 

        foreach (string testCase in testCases)
        {
            bool isGood = IsGoodBinaryString(testCase);
            Console.WriteLine($"Binary String: {testCase} is {(isGood ? "Good" : "Bad")}");
        }
        Console.ReadKey();
    }
}